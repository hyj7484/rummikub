export const color = {
    
} ;

// Center Container 크기
export const CENTER_CONTAINER_WITDH = 937.5 ;
export const CENTER_CONTAINER_HEIGHT = 575 ;

// Tail 크기
export const TAIL_WIDTH = 45 ;
export const TAIL_HEIGHT = 60 ;

// 충돌 값
export const WALL_COLLISION = 30 ;

// tail Section height
export const TAIL_SECITON_HEIGHT = 60 ;

// timer 기본값 
export const LNITIAL_TIME = 60 ;


export const IP = '192.168.0.30:9200' ;